// ======================== Firebase Setup ========================
// استيراد مكتبات Firebase من المصادر الرسمية
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  setDoc,
  updateDoc,
  increment
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

// إعداد تكوين Firebase باستخدام بيانات مشروعك
const firebaseConfig = {
  apiKey: "AIzaSyAJYlvdQIUdTG3Nmnz8f3oBfxH1GdZGh7Y",
  authDomain: "firezone-game.firebaseapp.com",
  projectId: "firezone-game",
  storageBucket: "firezone-game.appspot.com",
  messagingSenderId: "859919057428",
  appId: "1:859919057428:web:b46ef9b6b60fa894451d01"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ======================== Paymob Integration Setup ========================
// مفاتيح Paymob للاختبار (Sandbox)
const PAYMOB_API_KEY = "ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SmpiR0Z6Y3lJNklrMWxjbU5vWVc1MElpd2ljSEp2Wm1sc1pWOXdheUk2TVRBek1qWXhNQ3dpYm1GdFpTSTZJakUzTkRJNU1UUTNPVFl1TlRBeU9EZ3lJbjAuVk5ZdVh0VXYxaVBHV3k5UWhVYVp3RXh4UHV1NXVidFdaYmhabnZSV0pUc1kwYnY1S3hEWjVIT2RNanFibjF1VThVbzBhbUw4NDR2aWFEZlBEWnpWcWc=";
const PAYMOB_SECRET_KEY = "egy_sk_test_3a25ab5a9de78eff03e0cba464583493ba560911b7d056e66a04b3a4602029b3";
const PAYMOB_PUBLIC_KEY = "egy_pk_test_eDjAf7Aqw8UCvsu0WDPobU4SvMTVHElR";

// ======================== Global Variable ========================
let currentPaymentData = null;

// ======================== Utility Function ========================
// دالة لإرجاع بيانات الفوترة الافتراضية؛ يمكن تعديلها لتصبح ديناميكية
function getBillingData() {
  return {
    first_name: "John",
    last_name: "Doe",
    phone_number: "01012345678",
    email: "john.doe@example.com",
    apartment: "NA",
    floor: "NA",
    street: "NA",
    building: "NA",
    postal_code: "00000",
    city: "Cairo",
    country: "EG",
    state: "NA"
  };
}

// ======================== Payment Functions ========================

// Unified Checkout: إنشاء Intention باستخدام Unified Checkout
// paymentMethods تُحدد طرق الدفع المطلوبة؛ نمرر [5023821] لبطاقات فيزا/ماستر كارد أو [5024156] للمحفظة الإلكترونية
async function initiateUnifiedCheckout(amount, paymentMethods) {
  // تحويل المبلغ من الجنيه إلى القروش
  const amountInCents = amount * 100;
  const intentionUrl = "https://accept.paymob.com/v1/intention/"; // نقطة النهاية في Sandbox حسب الوثائق
  const body = {
    amount: amountInCents, // إرسال المبلغ بوحدة القروش
    currency: "EGP",
    payment_methods: paymentMethods, // مثال: [5023821] أو [5024156]
    items: [
      {
        name: "Fire Tokens",
        amount: amountInCents,
        description: "Purchase Fire Tokens",
        quantity: 1
      }
    ],
    billing_data: getBillingData(),
    customer: {
      first_name: "John",
      last_name: "Doe",
      email: "john.doe@example.com",
      extras: { re: "22" }
    },
    extras: { ee: 22 }
  };

  try {
    const response = await fetch(intentionUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${PAYMOB_SECRET_KEY}` // إرسال مفتاح Secret عبر الهيدر
      },
      body: JSON.stringify(body)
    });
    
    // إذا لم يكن الرد ناجحاً، اطبع تفاصيل الخطأ
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Response Error:", errorText);
      throw new Error(`HTTP Error: ${response.status}`);
    }
    
    const data = await response.json();
    console.log("Unified Checkout Intention Response:", data);
    const clientSecret = data.client_secret;
    if (!clientSecret) {
      alert("❌ لم يتم الحصول على client secret.");
      return;
    }
    // بناء رابط Unified Checkout باستخدام Public Key والـ client_secret
    const unifiedUrl = `https://accept.paymob.com/unifiedcheckout/?publicKey=${PAYMOB_PUBLIC_KEY}&clientSecret=${clientSecret}`;
    const paymobContainer = document.getElementById("paymob-iframe");
    if (paymobContainer) {
      paymobContainer.innerHTML = `<iframe src="${unifiedUrl}" frameborder="0" style="width:100%;height:500px;"></iframe>`;
      paymobContainer.classList.remove("hidden");
      paymobContainer.scrollIntoView({ behavior: "smooth" });
    } else {
      alert("❌ لم يتم العثور على عنصر الدفع في الصفحة.");
    }
  } catch (error) {
    console.error("❌ خطأ أثناء بدء Unified Checkout:", error);
    alert("❌ حدث خطأ أثناء بدء عملية الدفع عبر Unified Checkout. تفاصيل الخطأ موجودة في Console.");
  }
}

// دالة بدء الدفع باستخدام Unified Checkout بناءً على الطريقة المختارة
async function initiatePaymobPayment(amount, method) {
  if (method === "visa") {
    // عند اختيار فيزا/ماستر كارد نستخدم Unified Checkout مع payment_methods: [5023821]
    await initiateUnifiedCheckout(amount, [5023821]);
  } else if (method === "wallet") {
    // عند اختيار المحافظ الإلكترونية نستخدم Unified Checkout مع payment_methods: [5024156]
    await initiateUnifiedCheckout(amount, [5024156]);
  }
}

// ======================== Authentication & Payment Functions ========================

// دالة تسجيل مستخدم جديد: إعادة التوجيه مباشرة بعد النجاح بدون تنبيه
async function register() {
  const email = document.getElementById('email')?.value;
  const password = document.getElementById('password')?.value;
  if (!email || !password) {
    alert('❌ يرجى ملء جميع الحقول!');
    return;
  }
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, "Players", userCredential.user.uid), { Email: email, FireTokens: 0 });
    window.location.href = "index.store.html";
    checkLoginStatus();
  } catch (error) {
    alert(`❌ خطأ: ${error.message}`);
  }
}

// دالة تسجيل الدخول: إعادة التوجيه مباشرة بعد النجاح بدون تنبيه
async function login() {
  const email = document.getElementById('loginEmail')?.value;
  const password = document.getElementById('loginPassword')?.value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
    window.location.href = "index.store.html";
    checkLoginStatus();
  } catch (error) {
    alert(`❌ خطأ: ${error.message}`);
  }
}

// دالة تسجيل الخروج: خروج فوري بدون تنبيه
async function logoutAndRedirect() {
  try {
    await signOut(auth);
    window.location.href = "index.html";
  } catch (error) {
    alert(`❌ خطأ أثناء تسجيل الخروج: ${error.message}`);
  }
}

// متابعة حالة تسجيل الدخول لتحديث الواجهة ديناميكيًا
function checkLoginStatus() {
  onAuthStateChanged(auth, user => {
    const userInfo = document.getElementById('user-info');
    const logoutBtn = document.getElementById('logout-btn');
    const authSection = document.querySelector('.auth');
    const guestAuthBtn = document.getElementById('guest-auth-btn');
    if (user) {
      if (userInfo) userInfo.textContent = `مرحبًا، ${user.email}`;
      if (logoutBtn) logoutBtn.classList.remove('hidden');
      if (authSection) authSection.classList.add('hidden');
      if (guestAuthBtn) guestAuthBtn.classList.add('hidden');
    } else {
      if (userInfo) userInfo.textContent = '';
      if (logoutBtn) logoutBtn.classList.add('hidden');
      if (authSection) authSection.classList.remove('hidden');
      if (guestAuthBtn) guestAuthBtn.classList.remove('hidden');
    }
  });
}

// دالة إدارة الدفع عند اختيار طريقة الدفع
function handlePaymentMethod(method) {
  if (!auth.currentUser) return alert('❌ يجب تسجيل الدخول أولاً!');
  if (!currentPaymentData) return alert('❌ الرجاء اختيار باقة أولاً!');
  const { tokens, price } = currentPaymentData;
  initiatePaymobPayment(price, method);
}

// دالة شراء العملات
function purchase(tokens, price) {
  if (!auth.currentUser) return alert("❌ يجب تسجيل الدخول أولاً!");
  currentPaymentData = { tokens, price };
  if (confirm(`هل تريد شراء ${tokens} عملة بـ ${price} جنيه؟`)) {
    document.querySelector('.payment').scrollIntoView({ behavior: "smooth" });
  }
}

// دالة تبديل العرض بين نمطي تسجيل الدخول وإنشاء الحساب
function toggleAuth(event) {
  event.preventDefault();
  document.querySelectorAll('.auth-box').forEach(box => box.classList.toggle('hidden'));
}

// دالة إعادة تعيين كلمة المرور
async function resetPassword() {
  const email = prompt("أدخل بريدك الإلكتروني:");
  if (!email) return alert("❌ يرجى إدخال بريد إلكتروني صحيح.");
  try {
    await sendPasswordResetEmail(auth, email);
    alert("✅ تم إرسال رابط إعادة التعيين إلى بريدك الإلكتروني.");
  } catch (error) {
    alert(`❌ خطأ: ${error.message}`);
  }
}

// ربط الأحداث عند تحميل الصفحة للتأكد من جاهزية العناصر
document.addEventListener('DOMContentLoaded', () => {
  const registerBtn = document.getElementById('register-btn');
  if (registerBtn) registerBtn.addEventListener('click', register);

  const loginBtn = document.getElementById('login-btn');
  if (loginBtn) loginBtn.addEventListener('click', login);

  const toggleLogin = document.getElementById('toggle-login');
  if (toggleLogin) toggleLogin.addEventListener('click', toggleAuth);

  const toggleRegister = document.getElementById('toggle-register');
  if (toggleRegister) toggleRegister.addEventListener('click', toggleAuth);

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) logoutBtn.addEventListener('click', logoutAndRedirect);

  const resetPasswordBtn = document.getElementById('reset-password');
  if (resetPasswordBtn) resetPasswordBtn.addEventListener('click', resetPassword);

  checkLoginStatus();
});

// جعل بعض الدوال متاحة عالميًا للاستخدام في HTML (مثل onclick)
window.purchase = purchase;
window.handlePaymentMethod = handlePaymentMethod;
window.logoutAndRedirect = logoutAndRedirect;
