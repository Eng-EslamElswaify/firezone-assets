// /htdocs/admin.js
import { auth, db, storage } from "./firebase-init.js";
import { 
  onAuthStateChanged, 
  signOut 
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import {
  collection, getDocs, getDoc,
  addDoc, updateDoc, deleteDoc,
  doc, Timestamp, query, orderBy
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";
import {
  ref as storageRef,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from "https://www.gstatic.com/firebasejs/12.3.0/firebase-storage.js";

// Main initialization logic runs after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Authentication check
    onAuthStateChanged(auth, user => {
        if (user && user.email === "eslam.swaify@gmail.com") {
            // Ensure lang script is ready, then initialize
            if (window.lang) {
                initializeAdminPanel();
            } else {
                console.warn('Language script not ready, delaying admin panel initialization.');
                setTimeout(initializeAdminPanel, 250); // Fallback if lang.js is slow
            }
        } else {
            window.location.href = "index.html";
        }
    });

    // Logout button event listener
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            await signOut(auth);
            window.location.href = "index.html";
        });
    }
});

// This function sets up all the interactive parts of the admin panel
function initializeAdminPanel() {
  const mainSections = [
    document.getElementById('posts-section'),
    document.getElementById('gameplay-section')
  ];
  const formSections = [
    document.getElementById('postFormSection'),
    document.getElementById('gameplayPostFormSection')
  ];

  const showForm = (formToShow) => {
    mainSections.forEach(s => s.classList.add('hidden'));
    formSections.forEach(f => f.classList.add('hidden'));
    formToShow.classList.remove('hidden');
  };

  const hideForms = () => {
    formSections.forEach(f => f.classList.add('hidden'));
    mainSections.forEach(s => s.classList.remove('hidden'));
  };

  // Setup News Posts Section
  setupSection({
    collectionName: "posts",
    tableId: "postsTable",
    newBtnId: "newPostBtn",
    formId: "postForm",
    formTitleId: "formTitle",
    cancelBtnId: "cancelBtn",
    fields: {
      title: "title",
      content: "content",
      imageInput: "imageInput",
      imageUrlInput: "imageUrlInput",
      imagePreview: "imagePreview",
      postId: "postId"
    },
    showForm: () => showForm(formSections[0]),
    hideForm: hideForms,
  });

  // Setup Gameplay Posts Section
  setupSection({
    collectionName: "gameplay_posts",
    tableId: "gameplayPostsTable",
    newBtnId: "newGameplayPostBtn",
    formId: "gameplayPostForm",
    formTitleId: "gameplayFormTitle",
    cancelBtnId: "gameplayCancelBtn",
    fields: {
      title: "gameplayTitle",
      content: "gameplayContent",
      imageInput: "gameplayImageInput",
      imageUrlInput: "gameplayImageUrlInput",
      imagePreview: "gameplayImagePreview",
      postId: "gameplayPostId"
    },
    showForm: () => showForm(formSections[1]),
    hideForm: hideForms,
  });
}

// Generic Section Setup Function
function setupSection(config) {
  const tableBody = document.getElementById(config.tableId)?.querySelector("tbody");
  const newBtn = document.getElementById(config.newBtnId);
  const form = document.getElementById(config.formId);
  const formTitle = document.getElementById(config.formTitleId);
  const cancelBtn = document.getElementById(config.cancelBtnId);
  const { fields } = config;
  let editId = null;

  // Ensure elements exist before proceeding
  if (!tableBody || !newBtn || !form || !formTitle || !cancelBtn) {
      console.error(`Initialization failed for section with table ID: ${config.tableId}. One or more elements are missing.`);
      return;
  }

  const titleInput = document.getElementById(fields.title);
  const contentInput = document.getElementById(fields.content);
  const imageInput = document.getElementById(fields.imageInput);
  const imageUrlInput = document.getElementById(fields.imageUrlInput);
  const imagePreview = document.getElementById(fields.imagePreview);
  const postIdInput = document.getElementById(fields.postId);

  async function fetchAndRender() {
    tableBody.innerHTML = `<tr><td colspan="2">${window.lang.t('loading')}</td></tr>`;
    try {
        const q = query(collection(db, config.collectionName), orderBy("created", "desc"));
        const snapshot = await getDocs(q);
        tableBody.innerHTML = snapshot.empty ? `<tr><td colspan="2">${window.lang.t('noContent')}</td></tr>` : "";
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          const row = tableBody.insertRow();
          row.innerHTML = `
            <td>
              ${data.imageUrl ? `<img src="${data.imageUrl}" class="admin-table-img">` : ''}
              <div class="admin-table-title">${data.title || ''}</div>
            </td>
            <td>
              <button class="edit-btn btn-admin" data-id="${docSnap.id}">${window.lang.t('editBtn')}</button>
              <button class="delete-btn btn-admin-danger" data-id="${docSnap.id}">${window.lang.t('deleteBtn')}</button>
            </td>`;
        });
    } catch (err) {
        console.error(`Error fetching data for ${config.collectionName}:`, err);
        tableBody.innerHTML = `<tr><td colspan="2">${window.lang.t('dataLoadError')}</td></tr>`;
    }
  }

  newBtn.addEventListener('click', () => {
    editId = null;
    form.reset();
    imagePreview.innerHTML = "";
    postIdInput.value = "";
    formTitle.textContent = window.lang.t('addNewItem');
    config.showForm();
  });

  cancelBtn.addEventListener('click', config.hideForm);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    
    try {
      const file = imageInput.files[0];
      const manualUrl = imageUrlInput.value.trim();
      let imageUrl = null;
      let currentDoc = null;

      if (editId) {
          currentDoc = await getDoc(doc(db, config.collectionName, editId));
      }

      if (file) {
        const imgRef = storageRef(storage, `${config.collectionName}/${Date.now()}_${file.name}`);
        const snap = await uploadBytes(imgRef, file);
        imageUrl = await getDownloadURL(snap.ref);
      } else if (manualUrl) {
        imageUrl = manualUrl;
      } else if (currentDoc && currentDoc.exists()) {
        imageUrl = currentDoc.data().imageUrl; 
      }

      const payload = {
        title: titleInput.value.trim(),
        content: contentInput.value.trim(),
        updated: Timestamp.now(),
        imageUrl: imageUrl || '',
      };

      if (editId) {
        const docRef = doc(db, config.collectionName, editId);
        await updateDoc(docRef, payload);
      } else {
        payload.created = Timestamp.now();
        await addDoc(collection(db, config.collectionName), payload);
      }

      fetchAndRender();
      config.hideForm();
    } catch (error) {
      console.error("Error saving post:", error);
      alert(window.lang.t('saveError'));
    } finally {
      submitButton.disabled = false;
      form.reset();
    }
  });

  tableBody.addEventListener('click', async (e) => {
    const target = e.target;
    const id = target.dataset.id;
    if (!id || !target.classList.contains('btn-admin') && !target.classList.contains('btn-admin-danger')) return;

    const docRef = doc(db, config.collectionName, id);

    if (target.classList.contains('edit-btn')) {
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
          const data = docSnap.data();
          editId = id;
          postIdInput.value = id;
          titleInput.value = data.title || '';
          contentInput.value = data.content || '';
          imageUrlInput.value = data.imageUrl || '';
          imagePreview.innerHTML = data.imageUrl ? `<img src="${data.imageUrl}" class="image-preview-img">` : "";
          formTitle.textContent = window.lang.t('editItem');
          config.showForm();
      }
    } else if (target.classList.contains('delete-btn')) {
      if (confirm(window.lang.t('deleteConfirm'))) {
        try {
          const docSnap = await getDoc(docRef);
          if (docSnap.exists() && docSnap.data().imageUrl) {
            const oldUrl = docSnap.data().imageUrl;
            if (oldUrl.includes('firebasestorage.googleapis.com')){
                try {
                    const oldImageRef = storageRef(storage, oldUrl);
                    await deleteObject(oldImageRef);
                } catch (err) {
                    console.warn("Could not delete old image, it might not exist or rules are blocking:", err);
                }
            }
          }
          await deleteDoc(docRef);
          fetchAndRender();
        } catch (error) {
          console.error("Error deleting post:", error);
          alert(window.lang.t('deleteError'));
        }
      }
    }
  });

  fetchAndRender();
}