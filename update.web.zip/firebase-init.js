// /htdocs/firebase-init.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import { getFirestore }  from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";
import { getAuth }       from "https://www.gstatic.com/firebasejs/12.3.0/firebase-auth.js";
import { getStorage }    from "https://www.gstatic.com/firebasejs/12.3.0/firebase-storage.js";

const firebaseConfig = {
  apiKey:            "AIzaSyAJYlvdQIUdTG3Nmnz8f3oBfxH1GdZGh7Y",
  authDomain:        "firezone-game.firebaseapp.com",
  databaseURL:       "https://firezone-game-default-rtdb.firebaseio.com",
  projectId:         "firezone-game",
  storageBucket:     "firezone-game.appspot.com",
  messagingSenderId: "859919057428",
  appId:             "1:859919057428:web:b46ef9b6b60fa894451d01"
};

const app     = initializeApp(firebaseConfig);
export const db      = getFirestore(app);
export const auth    = getAuth(app);
export const storage = getStorage(app);
