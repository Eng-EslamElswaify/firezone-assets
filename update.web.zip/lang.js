// lang.js
;(function(window) {
  // 1. Configuration
  const defaultLang = 'ar';
  const supportedLangs = {
      ar: 'العربية',
      en: 'English',
      fr: 'Français',
      es: 'Español'
  };

  // 2. Translations Object
  const translations = {
    // ================= Arabic (ar) =================
    ar: {
      // --- Static Pages Content ---
      "privacyTitle": "سياسة الخصوصية",
      "privacyContent": "<p>هذه هي سياسة الخصوصية الخاصة بنا. نحن نأخذ خصوصيتك على محمل الجد. نجمع المعلومات التي تقدمها طواعية ونستخدمها لتحسين خدماتنا. نحن لا نشارك معلوماتك مع أطراف ثالثة دون موافقتك.</p><p>تفاصيل حول البيانات التي نجمعها...</p>",
      "termsTitle": "شروط الاستخدام",
      "termsContent": "<p>مرحبًا بك في FIRE ZONE GAME. باستخدام خدماتنا، فإنك توافق على هذه الشروط. يرجى قراءتها بعناية.</p><p><strong>1. استخدام خدماتنا:</strong> يجب عليك اتباع أي سياسات متاحة لك ضمن الخدمات. لا تسيء استخدام خدماتنا.</p><p><strong>2. حسابك:</strong> قد تحتاج إلى حساب لاستخدام بعض خدماتنا. أنت مسؤول عن أمان حسابك.</p>",
      // --- General ---
      "fireZone": "FIRE ZONE",
      "gameplayLink": "طريقة اللعب",
      "contactLink": "اتصل بنا",
      "privacyLink": "سياسة الخصوصية",
      "termsLink": "شروط الاستخدام",
      "allRightsReserved": "© 2024 FIRE ZONE GAME. جميع الحقوق محفوظة.",
      "loading": "جارٍ التحميل...",
      "noPosts": "لا توجد منشورات حالياً.",
      "email": "البريد الإلكتروني",
      "password": "كلمة المرور",
      "backToLogin": "العودة للصفحة الرئيسية",
      "pageTitle_Login": "تسجيل الدخول - FIRE ZONE GAME",
      "createAccountTitle": "إنشاء حساب جديد",
      "loginTitle": "تسجيل الدخول",
      "createAccountBtn": "إنشاء حساب",
      "loginBtn": "تسجيل الدخول",
      "switchToLogin": "لديك حساب؟ <a href=\"#\" id=\"toggle-login\">تسجيل الدخول</a>",
      "switchToRegister": "لا تمتلك حساب؟ <a href=\"#\" id=\"toggle-register\">إنشاء حساب</a>",
      "guestLink": "دخول كضيف",
      "forgotPassword": "نسيت كلمة المرور؟",
      "logoutBtn": "تسجيل الخروج",
      "postsSectionTitle": "آخر المنشورات",
      "resetPasswordTitle": "استعادة كلمة المرور",
      "resetEmailPlaceholder": "أدخل بريدك الإلكتروني",
      "sendLinkBtn": "إرسال الرابط",
      "cancelBtn": "إلغاء",
      "msgResetSent": "تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.",
      "pageTitle_Store": "متجر FireZone - FIRE ZONE GAME",
      "storeTitle": "متجر FireZone",
      "buyFireTokens": "اشحن عملات Fire Tokens",
      "buyNowBtn": "شراء الآن",
      "paymentMethodsTitle": "💳 طرق الدفع المتاحة",
      "payMethodVisa": "Visa/MasterCard",
      "payMethodVodafone": "فودافون كاش",
      "supportTitle": "📞 الدعم الفني",
      "supportEmail": "✉️ البريد الإلكتروني: <a href=\"mailto:eslam.swaify@gmail.com\">eslam.swaify@gmail.com</a>",
      "supportWhatsApp": "📞 واتساب: <a href=\"https://wa.me/201152906682\">+201152906682</a>",
      "downloadGameTitle": "📥 تحميل اللعبة",
      "downloadBtn": "تحميل الآن",
      "pageTitle_Gameplay": "طريقة اللعب - FIRE ZONE GAME",
      "gameplayTitle": "طريقة اللعب",
      "gameplaySectionTitle": "محتوى صفحة طريقة اللعب",
      "pageTitle_Privacy": "سياسة الخصوصية - FIRE ZONE GAME",
      "pageTitle_Terms": "شروط الاستخدام - FIRE ZONE GAME",
      "pageTitle_Contact": "تواصل معنا - FIRE ZONE GAME",
      "contactTitle": "تواصل معنا",
      "contactInfoTitle": "معلومات التواصل",
      "sendMessageTitle": "أرسل رسالة",
      "nameLabel": "الاسم:",
      "messageLabel": "رسالتك:",
      "sendBtn": "إرسال الرسالة",
      "namePlaceholder": "اكتب اسمك هنا",
      "messagePlaceholder": "اكتب رسالتك هنا",
      "pageTitle_Admin": "لوحة التحكم - FIRE ZONE GAME",
      "adminPanelTitle": "لوحة التحكم",
      "gameNewsLink": "أخبار اللعبة",
      "latestPostsTitle": "إدارة منشورات الأخبار",
      "addPostBtn": "إضافة منشور جديد",
      "tableTitleHeader": "العنوان",
      "tableActionsHeader": "الإجراءات",
      "editBtn": "تعديل",
      "deleteBtn": "حذف",
      "addFormTitle": "إضافة منشور جديد",
      "editFormTitle": "تعديل المنشور",
      "postTitleLabel": "عنوان المنشور",
      "postContentLabel": "محتوى المنشور",
      "imageUploadLabel": "رفع صورة للمنشور (اختياري)",
      "imageUrlLabel": "أو أدخل رابط الصورة يدويًا",
      "saveBtn": "حفظ التغييرات",
      "noContent": "لا يوجد محتوى لعرضه هنا بعد.",
      "dataLoadError": "حدث خطأ أثناء تحميل البيانات من الخادم.",
      "addNewItem": "إضافة عنصر جديد",
      "editItem": "تعديل العنصر",
      "deleteConfirm": "هل أنت متأكد من رغبتك في حذف هذا العنصر؟ لا يمكن التراجع عن هذا الإجراء.",
      "saveError": "حدث خطأ أثناء الحفظ.",
      "deleteError": "حدث خطأ أثناء الحذف.",
      "gameplaySectionAdminTitle": "إدارة محتوى قسم طريقة اللعب"
    },
    // ================= English (en) =================
    en: {
      "privacyTitle": "Privacy Policy",
      "privacyContent": "<p>This is our privacy policy. We take your privacy seriously. We collect information that you voluntarily provide and use it to improve our services. We do not share your information with third parties without your consent.</p><p>Details about the data we collect...</p>",
      "termsTitle": "Terms of Use",
      "termsContent": "<p>Welcome to FIRE ZONE GAME. By using our services, you agree to these terms. Please read them carefully.</p><p><strong>1. Using our Services:</strong> You must follow any policies made available to you within the Services. Don’t misuse our Services.</p><p><strong>2. Your Account:</strong> You may need an account to use some of our Services. You are responsible for the security of your account.</p>",
      "fireZone": "FIRE ZONE",
      "gameplayLink": "Gameplay",
      "contactLink": "Contact Us",
      "privacyLink": "Privacy Policy",
      "termsLink": "Terms of Use",
      "allRightsReserved": "© 2024 FIRE ZONE GAME. All rights reserved.",
      "loading": "Loading...",
      "noPosts": "No posts found.",
      "email": "Email",
      "password": "Password",
      "backToLogin": "Back to Home",
      "pageTitle_Login": "Login - FIRE ZONE GAME",
      "createAccountTitle": "Create New Account",
      "loginTitle": "Login",
      "createAccountBtn": "Create Account",
      "loginBtn": "Login",
      "switchToLogin": "Already have an account? <a href=\"#\" id=\"toggle-login\">Login</a>",
      "switchToRegister": "Don't have an account? <a href=\"#\" id=\"toggle-register\">Create one</a>",
      "guestLink": "Continue as Guest",
      "forgotPassword": "Forgot password?",
      "logoutBtn": "Log out",
      "postsSectionTitle": "Latest Posts",
      "resetPasswordTitle": "Reset your password",
      "resetEmailPlaceholder": "Enter your email",
      "sendLinkBtn": "Send link",
      "cancelBtn": "Cancel",
      "msgResetSent": "Password reset link sent to your email.",
      "pageTitle_Store": "FireZone Store - FIRE ZONE GAME",
      "storeTitle": "FireZone Store",
      "buyFireTokens": "Purchase Fire Tokens",
      "buyNowBtn": "Buy Now",
      "paymentMethodsTitle": "💳 Available Payment Methods",
      "payMethodVisa": "Visa/MasterCard",
      "payMethodVodafone": "Vodafone Cash",
      "supportTitle": "📞 Support",
      "supportEmail": "✉️ Email: <a href=\"mailto:eslam.swaify@gmail.com\">eslam.swaify@gmail.com</a>",
      "supportWhatsApp": "📞 WhatsApp: <a href=\"https://wa.me/201152906682\">+201152906682</a>",
      "downloadGameTitle": "📥 Download Game",
      "downloadBtn": "Download Now",
      "pageTitle_Gameplay": "Gameplay - FIRE ZONE GAME",
      "gameplayTitle": "Gameplay",
      "gameplaySectionTitle": "Gameplay Page Content",
      "pageTitle_Privacy": "Privacy Policy - FIRE ZONE GAME",
      "pageTitle_Terms": "Terms of Use - FIRE ZONE GAME",
      "pageTitle_Contact": "Contact Us - FIRE ZONE GAME",
      "contactTitle": "Contact Us",
      "contactInfoTitle": "Contact Information",
      "sendMessageTitle": "Send a Message",
      "nameLabel": "Name:",
      "messageLabel": "Your Message:",
      "sendBtn": "Send Message",
      "namePlaceholder": "Type your name here",
      "messagePlaceholder": "Type your message here",
      "pageTitle_Admin": "Admin Panel - FIRE ZONE GAME",
      "adminPanelTitle": "Admin Panel",
      "gameNewsLink": "Game News",
      "latestPostsTitle": "Manage News Posts",
      "addPostBtn": "Add New Post",
      "tableTitleHeader": "Title",
      "tableActionsHeader": "Actions",
      "editBtn": "Edit",
      "deleteBtn": "Delete",
      "addFormTitle": "Add New Post",
      "editFormTitle": "Edit Post",
      "postTitleLabel": "Post Title",
      "postContentLabel": "Post Content",
      "imageUploadLabel": "Upload Post Image (optional)",
      "imageUrlLabel": "Or enter image URL manually",
      "saveBtn": "Save Changes",
      "noContent": "No content to display here yet.",
      "dataLoadError": "Error loading data from the server.",
      "addNewItem": "Add New Item",
      "editItem": "Edit Item",
      "deleteConfirm": "Are you sure you want to delete this item? This action cannot be undone.",
      "saveError": "An error occurred while saving. Please check the console for details.",
      "deleteError": "An error occurred while deleting.",
      "gameplaySectionAdminTitle": "Manage Gameplay Content"
    },
    // Other languages omitted for brevity...
    fr: {},
    es: {}
  };
  
  // Auto-fill other languages from English to avoid errors
  ['fr', 'es'].forEach(lang => {
      for (const key in translations.en) {
          if (!translations[lang][key]) {
              translations[lang][key] = translations.en[key];
          }
      }
  });

  // 3. Core Functions
  function setLanguage(lang) {
    if (supportedLangs[lang]) {
        localStorage.setItem('siteLanguage', lang);
        location.reload();
    }
  }

  function getLanguage() {
    return localStorage.getItem('siteLanguage') || defaultLang;
  }

  function _(id) {
    return document.getElementById(id);
  }

  function translateElement(id, key, prop = 'innerText') {
    const el = _(id);
    if (!el) return;
    const lang = getLanguage();
    const t = translations[lang];
    if (t && t[key] !== undefined) {
      if (prop === 'innerHTML') el.innerHTML = t[key];
      else if (prop === 'placeholder') el.placeholder = t[key];
      else el[prop] = t[key];
    }
  }
  
  function getTranslation(key) {
      const lang = getLanguage();
      return (translations[lang] && translations[lang][key]) || key;
  }

  // 4. Apply Translations on Load
  function applyAllTranslations() {
    const lang = getLanguage();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

    const pageKey = document.body.dataset.pageKey;

    if (pageKey) {
        document.title = getTranslation(`pageTitle_${pageKey}`);
    }

    // --- Global Elements ---
    translateElement('logoTitle', 'fireZone');
    translateElement('gameplayLinkNav', 'gameplayLink');
    translateElement('contactLinkFooter', 'contactLink');
    translateElement('privacyLinkFooter', 'privacyLink');
    translateElement('termsLinkFooter', 'termsLink');
    translateElement('copyright', 'allRightsReserved', 'innerHTML');

    // --- Page-Specific Translations ---
    switch(pageKey) {
        case 'Login':
            translateElement('registerTitle', 'createAccountTitle');
            translateElement('email', 'email', 'placeholder');
            translateElement('password', 'password', 'placeholder');
            translateElement('register-btn', 'createAccountBtn');
            translateElement('switchToLogin', 'switchToLogin', 'innerHTML');
            translateElement('loginTitle', 'loginTitle');
            translateElement('loginEmail', 'email', 'placeholder');
            translateElement('loginPassword', 'password', 'placeholder');
            translateElement('login-btn', 'loginBtn');
            translateElement('reset-password', 'forgotPassword');
            translateElement('switchToRegister', 'switchToRegister', 'innerHTML');
            translateElement('logout-btn', 'logoutBtn');
            translateElement('guestLink', 'guestLink');
            translateElement('postsSectionTitle', 'postsSectionTitle');
            translateElement('resetTitle', 'resetPasswordTitle');
            translateElement('resetEmail', 'resetEmailPlaceholder', 'placeholder');
            translateElement('resetSendBtn', 'sendLinkBtn');
            translateElement('resetCancelBtn', 'cancelBtn');
            break;
        case 'Store':
            translateElement('storeTitle', 'storeTitle');
            translateElement('buyFireTokensTitle', 'buyFireTokens');
            ['500','1500','3000','5000','8000','10000'].forEach(count => {
                const btn = _('buyBtn' + count);
                if(btn) btn.innerText = getTranslation('buyNowBtn');
            });
            translateElement('paymentTitle', 'paymentMethodsTitle', 'innerHTML');
            translateElement('payMethodVisa', 'payMethodVisa', 'innerHTML');
            const vodafoneBtn = _('payMethodWallet');
            if (vodafoneBtn) vodafoneBtn.innerHTML = `📱 ${getTranslation('payMethodVodafone')}`;
            translateElement('supportTitle', 'supportTitle','innerHTML');
            translateElement('supportEmail', 'supportEmail', 'innerHTML');
            translateElement('supportWhatsApp', 'supportWhatsApp', 'innerHTML');
            translateElement('downloadTitle', 'downloadGameTitle','innerHTML');
            translateElement('downloadBtn', 'downloadBtn');
            translateElement('guest-auth-btn', 'backToLogin');
            break;
        case 'Gameplay':
            translateElement('gameplayTitle', 'gameplayTitle');
            translateElement('gameplaySectionTitle', 'gameplaySectionTitle');
            break;
        case 'Contact':
            translateElement('contactTitle', 'contactTitle');
            translateElement('backBtnContact', 'backToLogin');
            translateElement('contactInfoTitle','contactInfoTitle');
            translateElement('sendMessageTitle','sendMessageTitle');
            translateElement('supportEmail', 'supportEmail', 'innerHTML');
            translateElement('supportWhatsApp', 'supportWhatsApp', 'innerHTML');
            translateElement('contactFormNameLabel','nameLabel');
            translateElement('contactFormEmailLabel','email');
            translateElement('contactFormMsgLabel','messageLabel');
            translateElement('contactFormSendBtn','sendBtn');
            translateElement('name','namePlaceholder','placeholder');
            translateElement('emailContact','email','placeholder');
            translateElement('message','messagePlaceholder','placeholder');
            break;
        case 'Privacy':
            translateElement('privacyTitle', 'privacyTitle');
            translateElement('privacyContent', 'privacyContent', 'innerHTML');
            translateElement('backBtn', 'backToLogin');
            break;
        case 'Terms':
            translateElement('termsTitle', 'termsTitle');
            translateElement('termsContent', 'termsContent', 'innerHTML');
            translateElement('backBtnTerms', 'backToLogin');
            break;
    }

    if (document.body.id === 'admin-page') {
        document.title = getTranslation('pageTitle_Admin');
        translateElement('adminPanelTitleHeader', 'adminPanelTitle');
        translateElement('gameNewsLink', 'gameNewsLink');
        translateElement('gameplayLinkAdmin', 'gameplayLink');
        translateElement('logoutBtn', 'logoutBtn');
        translateElement('latestPostsTitle', 'latestPostsTitle');
        translateElement('newPostBtn', 'addPostBtn');
        translateElement('postsTableTitleHeader', 'tableTitleHeader');
        translateElement('postsTableActionsHeader', 'tableActionsHeader');
        translateElement('gameplaySectionTitleAdmin', 'gameplaySectionAdminTitle');
        translateElement('newGameplayPostBtn', 'addPostBtn');
        translateElement('gameplayPostsTableTitleHeader', 'tableTitleHeader');
        translateElement('gameplayPostsTableActionsHeader', 'tableActionsHeader');
        translateElement('formTitle', 'addFormTitle'); 
        translateElement('titleLabel', 'postTitleLabel');
        translateElement('contentLabel', 'postContentLabel');
        translateElement('imageUploadLabel', 'imageUploadLabel');
        translateElement('imageUrlLabel', 'imageUrlLabel');
        translateElement('saveBtn', 'saveBtn');
        translateElement('cancelBtn', 'cancelBtn');
        translateElement('gameplayFormTitle', 'addFormTitle');
        translateElement('gameplayTitleLabel', 'postTitleLabel');
        translateElement('gameplayContentLabel', 'postContentLabel');
        translateElement('gameplayImageUploadLabel', 'imageUploadLabel');
        translateElement('gameplayImageUrlLabel', 'imageUrlLabel');
        translateElement('gameplaySaveBtn', 'saveBtn');
        translateElement('gameplayCancelBtn', 'cancelBtn');
    }
  }

  // 5. Language Switcher
  function createLanguageSwitcher() {
    const selector = _('languageSelector');
    if (selector) {
      selector.innerHTML = '';
      for (const langCode in supportedLangs) {
          const option = document.createElement('option');
          option.value = langCode;
          option.textContent = supportedLangs[langCode];
          selector.appendChild(option);
      }
      selector.value = getLanguage();
      selector.addEventListener('change', e => setLanguage(e.target.value));
    }
  }

  // 6. Expose to Global Scope & Initialize
  document.addEventListener('DOMContentLoaded', function() {
      createLanguageSwitcher();
      applyAllTranslations();
      
      if (document.body.dataset.pageKey === 'Login') {
          const switchToLoginLink = _('toggle-login');
          const switchToRegisterLink = _('toggle-register');
          const registerBox = _('registerBox');
          const loginBox = _('loginBox');
          if(switchToLoginLink && switchToRegisterLink && registerBox && loginBox){
              switchToLoginLink.addEventListener('click', e => {
                  e.preventDefault();
                  registerBox.classList.add('hidden');
                  loginBox.classList.remove('hidden');
              });
              switchToRegisterLink.addEventListener('click', e => {
                  e.preventDefault();
                  loginBox.classList.add('hidden');
                  registerBox.classList.remove('hidden');
              });
          }
      }
  });

  window.lang = {
    set: setLanguage,
    get: getLanguage,
    t: getTranslation,
    apply: applyAllTranslations
  };

})(window);